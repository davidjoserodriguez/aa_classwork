class Cat

    def initialize(name, age)
        @name = name
        @age = age
    end

    def name
        # p self
        @name
    end

    def self.class_name
        self
    end

    def self.says
        'Cats say Meow...'
    end

    def says
        self.name
        # "#{@name} says Meow... I'm hungry, feed me human..."
    end

end

# nemo = Cat.new('Captain Nemo', 6)